import tensorflow.keras as keras
import tensorflow as tf
import numpy as np
import time
import os

import utils


class Classifier_Inception:
    
    def __init__(self, output_directory, input_shape=None, nb_classes=0, verbose=False, build=True, batch_size=64, lr=0.001, nb_filters=32, use_residual=True, use_bottleneck=True, depth=6, kernel_size=41, nb_epochs=10):
        
        self.output_directory = output_directory
        self.model_directory = os.path.join(self.output_directory, 'models')
        self.plots_directory = os.path.join(self.output_directory, 'plots')
        self.metrics_directory = os.path.join(self.output_directory, 'metrics')
        
        self.nb_filters = nb_filters
        self.use_residual = use_residual
        self.use_bottleneck = use_bottleneck
        self.depth = depth
        self.kernel_size = kernel_size - 1
        self.callbacks = None
        self.batch_size = batch_size
        self.bottleneck_size = 32
        self.nb_epochs = nb_epochs
        self.lr = lr
        self.verbose = verbose
        
        if build == True:
            
            utils.create_directory(self.model_directory)
            
            self.model = self.build_model(input_shape, nb_classes)
            if (verbose == True):
                self.model.summary()
            
            self.model.save_weights(os.path.join(self.model_directory, 'model_init.hdf5'))

                
    def _inception_module(self, input_tensor, stride=1, activation='linear'):
        
        if self.use_bottleneck and int(input_tensor.shape[-1]) > self.bottleneck_size:
            input_inception = keras.layers.Conv1D(filters=self.bottleneck_size, kernel_size=1, padding='same', activation=activation, use_bias=False)(input_tensor)
        else:
            input_inception = input_tensor
                
        # kernel_size_s = [3, 5, 8, 11, 17]
        kernel_size_s = [self.kernel_size // (2 ** i) for i in range(3)]

        conv_list = []

        for i in range(len(kernel_size_s)):
            conv_list.append(keras.layers.Conv1D(filters=self.nb_filters, kernel_size=kernel_size_s[i], strides=stride, padding='same', activation=activation, use_bias=False)(input_inception))
                
        max_pool_1 = keras.layers.MaxPool1D(pool_size=3, strides=stride, padding='same')(input_tensor)
                
        conv_6 = keras.layers.Conv1D(filters=self.nb_filters, kernel_size=1, padding='same', activation=activation, use_bias=False)(max_pool_1)
                    
        conv_list.append(conv_6)
                                             
        x = keras.layers.Concatenate(axis=2)(conv_list)
        x = keras.layers.BatchNormalization()(x)
        x = keras.layers.Activation(activation='relu')(x)

        return x


    def _shortcut_layer(self, input_tensor, out_tensor):
        
        shortcut_y = keras.layers.Conv1D(filters=int(out_tensor.shape[-1]), kernel_size=1, padding='same', use_bias=False)(input_tensor)
        shortcut_y = keras.layers.BatchNormalization()(shortcut_y)

        x = keras.layers.Add()([shortcut_y, out_tensor])
        x = keras.layers.Activation('relu')(x)

        return x


    def build_model(self, input_shape, nb_classes):
        
        input_layer = keras.layers.Input(input_shape)
        
        x = input_layer
        input_res = input_layer
            
        for d in range(self.depth):
            
            x = self._inception_module(x)
            
            if self.use_residual and d % 3 == 2:
                x = self._shortcut_layer(input_res, x)
                input_res = x
        
        gap_layer = keras.layers.GlobalAveragePooling1D()(x)
            
        output_layer = keras.layers.Dense(nb_classes, activation='softmax')(gap_layer)
        
        model = keras.models.Model(inputs=input_layer, outputs=output_layer)
            
        model.compile(loss='categorical_crossentropy', optimizer=keras.optimizers.Adam(self.lr), metrics=['accuracy'])
                
        reduce_lr = keras.callbacks.ReduceLROnPlateau(monitor='loss', factor=0.5, patience=50, min_lr=0.0001)

        file_path = os.path.join(self.model_directory, 'best_model.hdf5')

        model_checkpoint = keras.callbacks.ModelCheckpoint(filepath=file_path, monitor='loss', save_best_only=True)
  
        self.callbacks = [reduce_lr, model_checkpoint]
                          
        return model
        
        
    def fit(self, x_train, y_train, x_val, y_val):

        #if not tf.test.is_gpu_available:
        #   print('error no gpu')
        #    exit()
        
        # x_val and y_val are only used to monitor the test loss and NOT for training
        if self.batch_size is None:
            mini_batch_size = int(min(x_train.shape[0] / 10, 16))
        else:
            mini_batch_size = self.batch_size
        
        start_time = time.time()
        
        hist = self.model.fit(x_train, y_train, batch_size=mini_batch_size, epochs=self.nb_epochs, verbose=self.verbose, validation_data=(x_val, y_val), callbacks=self.callbacks)
            
        duration = time.time() - start_time

        self.model.save(os.path.join(self.model_directory, 'last_model.hdf5'))
        
        utils.create_directory(self.metrics_directory)
        utils.save_fit_logs(self.metrics_directory, hist, duration)
        
        utils.create_directory(self.plots_directory)
        utils.plot_epochs_metric(self.plots_directory, hist)

        keras.backend.clear_session()


    def predict(self, x_test, y_true):

        model_path = os.path.join(self.model_directory, 'best_model.hdf5')
        
        model = keras.models.load_model(model_path)
        
        y_predict = model.predict(x_test, batch_size=self.batch_size)
        y_predict = np.argmax(y_predict, axis=1)
        
        utils.save_results(self.metrics_directory, y_true, y_predict)
        utils.calculate_metrics(self.metrics_directory, y_true, y_predict)

        return y_predict
